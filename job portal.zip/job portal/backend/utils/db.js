// import mongoose from "mongoose";

// import dotenv from 'dotenv';
// dotenv.config();


// const connectDB = async () => {
//   try {
//     await mongoose.connect(process.env.MONGO_URI, {
//       // useNewUrlParser: true,
//       // useUnifiedTopology: true,
//     });
//     console.log('MongoDB connected successfully');
//   } catch (error) {
//     console.log('Error connecting to MongoDB:', error.message);
//   }
// };

// export default connectDB;/

// utils/db.js
import mongoose from "mongoose";

export async function connectToMongoDB(url) {
    try {
        await mongoose.connect(url);
        console.log("MongoDB Connected!");
    } catch (error) {
        console.error("MongoDB connection error:", error);
        throw error;
    }
}

mongoose.connection.on("disconnected", () => {
    console.log("MongoDB Disconnected!");
});

mongoose.connection.on("connected", () => {
    console.log("MongoDB connected!");
});
