// import express from "express";
// import cookieParser from "cookie-parser";
// import cors from "cors";
// import dotenv from "dotenv";
// import connectDB from "./utils/db.js";
// import userRoute from "./routes/user.route.js";
// dotenv.config({});
// const app=express();

// const mongoURL = process.env.MONGO;


// //connection to mongoDB
// try{
//     connectToMongoDB(mongoURL)
//     .then(() => console.log("MongoDB Connected!"));
// }catch(error){
//     throw error;
// }

// //middleware
// app.use(express.json());
// app.use(express.urlencoded({extended:true}));
// app.use(cookieParser());
// const corsOptions={
//     origin:'https//:localhost:5173',
//     credentials:true
// }
// app.use(cors(corsOptions));
// const PORT=process.env.PORT || 3000;

// //apis
// app.use("/api/v1/user",userRoute);

// app.listen(PORT,()=>{
//     connectDB();
//     console.log(`Server running at port ${PORT}`);
// });

// index.js
/*  import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import { connectToMongoDB } from "./utils/db.js";  // Adjust import
import userRoute from "./routes/user.route.js";

dotenv.config();

const app = express();
const mongoURL = process.env.MONGO_URL;

// Connect to MongoDB
(async () => {
    try {
        await connectToMongoDB(mongoURL);  // Ensure MongoDB connection happens before server starts
    } catch (error) {
        console.error("Failed to connect to MongoDB", error);
        process.exit(1);  // Exit if DB connection fails
    }
})();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

const corsOptions = {
    origin: 'http://localhost:5173',  // Fix the CORS URL format
    credentials: true
};
app.use(cors(corsOptions));

const PORT = process.env.PORT || 8000;

// APIs
app.use("/api/v1/user/", userRoute);

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at port ${PORT}`);
});
*/

import express from "express";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";


dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(cors());
app.use(cookieParser());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Connected to MongoDB");
    })
    .catch((err) => {
        console.error("MongoDB connection error:", err);
    });

// Simple route for testing
app.get("/", (req, res) => {
    res.send("Hello, World!");
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

